/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author USER
 */
public class Struk {
    
    public Struk () {
        
    }
    
    String struk_id;
    String kode_sepatu;
    String model_sepatu;
    String merk_sepatu;
    String warna_sepatu;
    String harga_sepatu;
    String kuantitas_sepatu;
    String uang_pembayaran;

    public String getStruk_id() {
        return struk_id;
    }

    public void setStruk_id(String struk_id) {
        this.struk_id = struk_id;
    }

    public String getKode_sepatu() {
        return kode_sepatu;
    }

    public void setKode_sepatu(String kode_sepatu) {
        this.kode_sepatu = kode_sepatu;
    }

    public String getModel_sepatu() {
        return model_sepatu;
    }

    public void setModel_sepatu(String model_sepatu) {
        this.model_sepatu = model_sepatu;
    }

    public String getMerk_sepatu() {
        return merk_sepatu;
    }

    public void setMerk_sepatu(String merk_sepatu) {
        this.merk_sepatu = merk_sepatu;
    }

    public String getWarna_sepatu() {
        return warna_sepatu;
    }

    public void setWarna_sepatu(String warna_sepatu) {
        this.warna_sepatu = warna_sepatu;
    }

    public String getHarga_sepatu() {
        return harga_sepatu;
    }

    public void setHarga_sepatu(String harga_sepatu) {
        this.harga_sepatu = harga_sepatu;
    }

    public String getKuantitas_sepatu() {
        return kuantitas_sepatu;
    }

    public void setKuantitas_sepatu(String kuantitas_sepatu) {
        this.kuantitas_sepatu = kuantitas_sepatu;
    }

    public String getUang_pembayaran() {
        return uang_pembayaran;
    }

    public void setUang_pembayaran(String uang_pembayaran) {
        this.uang_pembayaran = uang_pembayaran;
    }
    
}
