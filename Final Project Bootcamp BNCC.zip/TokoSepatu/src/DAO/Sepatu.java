/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author USER
 */
public class Sepatu {

    public Sepatu() {

    }
    
    String kode_sepatu;
    String model_sepatu;
    String merk_sepatu;
    String warna_sepatu;
    String harga_sepatu;

    public Sepatu(String kode_sepatu, String model_sepatu, String merk_sepatu, String warna_sepatu, String harga_sepatu) {
        this.kode_sepatu = kode_sepatu;
        this.model_sepatu = model_sepatu;
        this.merk_sepatu = merk_sepatu;
        this.warna_sepatu = warna_sepatu;
        this.harga_sepatu = harga_sepatu;
    }

    public String getKode_sepatu() {
        return kode_sepatu;
    }

    public void setKode_sepatu(String kode_sepatu) {
        this.kode_sepatu = kode_sepatu;
    }

    public String getModel_sepatu() {
        return model_sepatu;
    }

    public void setModel_sepatu(String model_sepatu) {
        this.model_sepatu = model_sepatu;
    }

    public String getMerk_sepatu() {
        return merk_sepatu;
    }

    public void setMerk_sepatu(String merk_sepatu) {
        this.merk_sepatu = merk_sepatu;
    }

    public String getWarna_sepatu() {
        return warna_sepatu;
    }

    public void setWarna_sepatu(String warna_sepatu) {
        this.warna_sepatu = warna_sepatu;
    }

    public String getHarga_sepatu() {
        return harga_sepatu;
    }

    public void setHarga_sepatu(String harga_sepatu) {
        this.harga_sepatu = harga_sepatu;
    }
    
}
