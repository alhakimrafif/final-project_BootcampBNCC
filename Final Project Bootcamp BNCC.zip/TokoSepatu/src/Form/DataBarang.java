/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Form;

import Connection.ConnectionSet;
import DAO.Sepatu;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class DataBarang extends JFrame {

    Sepatu sepatu = new Sepatu();
    JPanel pane;       
    JPanel PaneMain;
    JButton btCancel;
    JButton btEdit;
    JButton btHapus;
    JButton btTambah;
    JLabel jLabel1;
    JLabel jLabel2;
    JLabel jLabel3;
    JLabel jLabel4;
    JLabel jLabel5;
    JLabel jLabel6;
    JScrollPane jScrollPane1;
    JTable tb_sepatu;
    JTextField txt_harga_sepatu;
    JTextField txt_kode_sepatu;
    JTextField txt_merk_sepatu;
    JTextField txt_model_sepatu;
    JTextField txt_warna_sepatu;
    
    Connection con;
    ConnectionSet cn = new ConnectionSet();
    PreparedStatement ps;
    ResultSet rs;
    DefaultTableModel dtm = new DefaultTableModel();

    public DataBarang() {
        setLayout();
        pane = PaneMain;
        listSepatu();
        loadpanitia();
        reset();
    }
                         
    public void setLayout() {

        PaneMain = new JPanel();
        jLabel3 = new JLabel();
        jScrollPane1 = new JScrollPane();
        tb_sepatu = new JTable();
        jLabel4 = new JLabel();
        txt_kode_sepatu = new JTextField();
        jLabel2 = new JLabel();
        txt_model_sepatu = new JTextField();
        jLabel5 = new JLabel();
        txt_merk_sepatu = new JTextField();
        jLabel6 = new JLabel();
        txt_warna_sepatu = new JTextField();
        jLabel1 = new JLabel();
        txt_harga_sepatu = new JTextField();
        btCancel = new JButton();
        btTambah = new JButton();
        btHapus = new JButton();
        btEdit = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        PaneMain.setOpaque(false);
        PaneMain.setPreferredSize(new Dimension(1060, 550));

        jLabel3.setFont(new Font("Chocolate Cookies", 1, 56));
        jLabel3.setForeground(new Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel3.setText("Data Barang");

        tb_sepatu.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Kode Sepatu", "Model Sepatu", "Merk Sepatu", "Warna Sepatu", "Harga Sepatu"
            }
        ));
        tb_sepatu.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                tb_sepatuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb_sepatu);

        jLabel4.setFont(new Font("Arial Black", 0, 14));
        jLabel4.setForeground(new Color(204, 204, 204));
        jLabel4.setText("Kode Sepatu");

        txt_kode_sepatu.setFont(new Font("Arial", 0, 12));
        txt_kode_sepatu.setForeground(new Color(204, 204, 204));
        txt_kode_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_kode_sepatu.setCaretColor(new Color(255, 255, 255));
        txt_kode_sepatu.setOpaque(false);

        jLabel2.setFont(new Font("Arial Black", 0, 14));
        jLabel2.setForeground(new Color(204, 204, 204));
        jLabel2.setText("Model Sepatu");

        txt_model_sepatu.setFont(new Font("Arial", 0, 12));
        txt_model_sepatu.setForeground(new Color(204, 204, 204));
        txt_model_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_model_sepatu.setCaretColor(new Color(255, 255, 255));
        txt_model_sepatu.setOpaque(false);

        jLabel5.setFont(new Font("Arial Black", 0, 14));
        jLabel5.setForeground(new Color(204, 204, 204));
        jLabel5.setText("Merk Sepatu");

        txt_merk_sepatu.setFont(new Font("Arial", 0, 12));
        txt_merk_sepatu.setForeground(new Color(204, 204, 204));
        txt_merk_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_merk_sepatu.setCaretColor(new Color(255, 255, 255));
        txt_merk_sepatu.setOpaque(false);

        jLabel6.setFont(new Font("Arial Black", 0, 14));
        jLabel6.setForeground(new Color(204, 204, 204));
        jLabel6.setText("Warna Sepatu");

        txt_warna_sepatu.setFont(new Font("Arial", 0, 12));
        txt_warna_sepatu.setForeground(new Color(204, 204, 204));
        txt_warna_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_warna_sepatu.setCaretColor(new Color(255, 255, 255));
        txt_warna_sepatu.setOpaque(false);

        jLabel1.setFont(new Font("Arial Black", 0, 14));
        jLabel1.setForeground(new Color(204, 204, 204));
        jLabel1.setText("Harga Sepatu");

        txt_harga_sepatu.setFont(new Font("Arial", 0, 12));
        txt_harga_sepatu.setForeground(new Color(204, 204, 204));
        txt_harga_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_harga_sepatu.setCaretColor(new Color(255, 255, 255));
        txt_harga_sepatu.setOpaque(false);

        btCancel.setText("Cancel");
        btCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btCancelActionPerformed(evt);
            }
        });

        btTambah.setText("Tambah");
        btTambah.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btTambahActionPerformed(evt);
            }
        });

        btHapus.setText("Hapus");
        btHapus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btHapusActionPerformed(evt);
            }
        });

        btEdit.setText("Edit");
        btEdit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btEditActionPerformed(evt);
            }
        });

        GroupLayout PaneMainLayout = new GroupLayout(PaneMain);
        PaneMain.setLayout(PaneMainLayout);
        PaneMainLayout.setHorizontalGroup(
            PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 1060, GroupLayout.PREFERRED_SIZE)
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 740, GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGroup(PaneMainLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(btTambah, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
                            .addComponent(btEdit, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))))
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(txt_kode_sepatu, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_model_sepatu, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_merk_sepatu, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_warna_sepatu, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_harga_sepatu, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btHapus, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btCancel, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)))
        );
        PaneMainLayout.setVerticalGroup(
            PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel3)
                .addGap(48, 48, 48)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 360, GroupLayout.PREFERRED_SIZE)
                    .addGroup(PaneMainLayout.createSequentialGroup()
                        .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btTambah, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btEdit, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE))
                    .addGroup(PaneMainLayout.createSequentialGroup()
                        .addComponent(txt_kode_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txt_model_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txt_merk_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txt_warna_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txt_harga_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btHapus, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btCancel, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE))))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(PaneMain, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(PaneMain, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }                     

    public void btCancelActionPerformed(ActionEvent evt) {                                         
        reset();
    }                                        

    public void btTambahActionPerformed(ActionEvent evt) {                                         
        if (txt_kode_sepatu.getText().equals("") || txt_model_sepatu.getText().equals("") || txt_merk_sepatu.getText().equals("") || txt_warna_sepatu.getText().equals("") || txt_harga_sepatu.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Data Harus Lengkap");
        } else {
            if (check(txt_kode_sepatu.getText())) {
            } else {
                char firstChar = txt_merk_sepatu.getText().charAt(0);
                if (passing == null) {
                    sepatu.setKode_sepatu(firstChar + "OO" + 1);
                } else {
                    String numberOnly = passing.replaceAll("[^0-9]", "");
                    int a = Integer.valueOf(numberOnly) + 1;
                    sepatu.setKode_sepatu(firstChar + "OO" + a);
                }
                sepatu.setModel_sepatu(txt_model_sepatu.getText());
                sepatu.setMerk_sepatu(txt_merk_sepatu.getText());
                sepatu.setWarna_sepatu(txt_warna_sepatu.getText());
                sepatu.setHarga_sepatu(txt_harga_sepatu.getText());
                saveSepatu(sepatu);
                JOptionPane.showMessageDialog(null, "Data Ditambah");
                setResetTable();
                loadpanitia();
                reset();
            }
        }
    }                                        

    public void btEditActionPerformed(ActionEvent evt) {                                       
        if (txt_kode_sepatu.getText().equals("") || txt_model_sepatu.getText().equals("") || txt_merk_sepatu.getText().equals("") || txt_warna_sepatu.getText().equals("") || txt_harga_sepatu.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Data Harus Lengkap");
        } else {
            sepatu.setKode_sepatu(txt_kode_sepatu.getText());
            sepatu.setModel_sepatu(txt_model_sepatu.getText());
            sepatu.setMerk_sepatu(txt_merk_sepatu.getText());
            sepatu.setWarna_sepatu(txt_warna_sepatu.getText());
            sepatu.setHarga_sepatu(txt_harga_sepatu.getText());
            updateSepatu(sepatu);
            JOptionPane.showMessageDialog(null, "Data Diedit");
            setResetTable();
            reset();
            loadpanitia();
        }
    }                                      

    public void btHapusActionPerformed(ActionEvent evt) {                                        
        if (!"".equals(txt_kode_sepatu.getText())) {
            int dialog = JOptionPane.showConfirmDialog(null, "Hapus?");
            if (dialog == 0) {
                deleteSepatu(txt_kode_sepatu.getText());
                setResetTable();
                loadpanitia();
                reset();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }                                       

    public void tb_sepatuMouseClicked(MouseEvent evt) {                                       
        clickTabel();
        int index = tb_sepatu.rowAtPoint(evt.getPoint());
        txt_kode_sepatu.setText(tb_sepatu.getValueAt(index, 1).toString());
        txt_model_sepatu.setText(tb_sepatu.getValueAt(index, 2).toString());
        txt_merk_sepatu.setText(tb_sepatu.getValueAt(index, 3).toString());
        txt_warna_sepatu.setText(tb_sepatu.getValueAt(index, 4).toString());
        txt_harga_sepatu.setText(tb_sepatu.getValueAt(index, 5).toString());
    }                                      

    public void setResetTable() {
        for (int i = 0; i < dtm.getRowCount(); i++) {
            dtm.removeRow(i);
            i = i - 1;
        }
    }

    public List listSepatu() {
        List<Sepatu> sepatus = new ArrayList();
        String sql = "SELECT * FROM sepatu";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Sepatu sepatu = new Sepatu();
                sepatu.setKode_sepatu(rs.getString("kode_sepatu"));
                sepatu.setModel_sepatu(rs.getString("model_sepatu"));
                sepatu.setMerk_sepatu(rs.getString("merk_sepatu"));
                sepatu.setWarna_sepatu(rs.getString("warna_sepatu"));
                sepatu.setHarga_sepatu(rs.getString("harga_sepatu"));
                sepatus.add(sepatu);
            }

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return sepatus;
    }

    public void loadpanitia() {
        List<Sepatu> sepatus = listSepatu();
        dtm = (DefaultTableModel) tb_sepatu.getModel();
        Object[] ob = new Object[6];
        for (int i = 0; i < sepatus.size(); i++) {
            ob[0] = i + 1;
            ob[1] = sepatus.get(i).getKode_sepatu();
            ob[2] = sepatus.get(i).getModel_sepatu();
            ob[3] = sepatus.get(i).getMerk_sepatu();
            ob[4] = sepatus.get(i).getWarna_sepatu();
            ob[5] = sepatus.get(i).getHarga_sepatu();
            dtm.addRow(ob);
        }
        tb_sepatu.setModel(dtm);
    }

    public void clickTabel() {
        btEdit.setEnabled(true);
        btHapus.setEnabled(true);
        btTambah.setEnabled(false);
        txt_kode_sepatu.setEnabled(false);
    }

    String passing;

    public void reset() {
        passing = null;
        int index = tb_sepatu.getRowCount();
        System.out.println(index + "dgdfg");
        if (index == 0) {

        } else {
            passing = String.valueOf(tb_sepatu.getValueAt(index - 1, 1));
            System.out.println(passing);
        }
        btEdit.setEnabled(false);
        btHapus.setEnabled(false);
        btTambah.setEnabled(true);
        txt_kode_sepatu.setEnabled(true);
        txt_kode_sepatu.setText("");
        txt_merk_sepatu.setText("");
        txt_model_sepatu.setText("");
        txt_warna_sepatu.setText("");
        txt_harga_sepatu.setText("");
    }

    public boolean deleteSepatu(String id_admin) {
        String sql = "DELETE FROM sepatu WHERE kode_sepatu = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, id_admin);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }

    public boolean updateSepatu(Sepatu sepatu) {
        String sql = "UPDATE sepatu SET "
                + "model_sepatu=?, merk_sepatu=?, warna_sepatu=?, harga_sepatu=? WHERE kode_sepatu=?";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            ps.setString(1, sepatu.getModel_sepatu());
            ps.setString(2, sepatu.getMerk_sepatu());
            ps.setString(3, sepatu.getWarna_sepatu());
            ps.setString(4, sepatu.getHarga_sepatu());
            ps.setString(5, sepatu.getKode_sepatu());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }

    public boolean saveSepatu(Sepatu sepatu) {
        String sql = "INSERT INTO sepatu "
                + "(kode_sepatu, model_sepatu, merk_sepatu, warna_sepatu, harga_sepatu) "
                + "VALUES (?,?,?,?,?)";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            ps.setString(1, sepatu.getKode_sepatu());
            ps.setString(2, sepatu.getModel_sepatu());
            ps.setString(3, sepatu.getMerk_sepatu());
            ps.setString(4, sepatu.getWarna_sepatu());
            ps.setString(5, sepatu.getHarga_sepatu());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }

    public boolean check(String kode_sepatu) {
        String sql = "SELECT * FROM sepatu where kode_sepatu = '" + kode_sepatu + "'";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Kode Sudah Di Pakai!");
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
}
