package Form;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MainMenu extends JFrame {

    JPanel MainPanel;
    JMenuBar MenuBarOption;
    JPanel PaneMain1;
    JPanel ParentPane;
    JLabel jlabel1;
    JLabel jlabel2;
    JLabel lblBackground;
    JMenuItem mnAbout;
    JMenuItem histori;
    JMenuItem databarang;
    JMenuItem kasir;
    JMenuItem mnMain;
    JMenu mnOption1;
    JMenu mnOption2;

    public MainMenu() {
        setLayout();
        setLocationRelativeTo(null);
    }

    public void setLayout() {

        MainPanel = new JPanel();
        ParentPane = new JPanel();
        PaneMain1 = new JPanel();
        jlabel1 = new JLabel();
        jlabel2 = new JLabel();
        lblBackground = new JLabel();
        MenuBarOption = new JMenuBar();
        mnOption1 = new JMenu();
        kasir = new JMenuItem();
        databarang = new JMenuItem();
        histori = new JMenuItem();
        mnOption2 = new JMenu();
        mnMain = new JMenuItem();
        mnAbout = new JMenuItem();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Penjualan Sepatu");
        setResizable(false);

        MainPanel.setOpaque(false);

        ParentPane.setOpaque(false);
        ParentPane.setLayout(new CardLayout());

        PaneMain1.setOpaque(false);

        jlabel1.setFont(new Font("Chocolate Cookies", 1, 56));
        jlabel1.setForeground(new Color(255, 255, 255));
        jlabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jlabel1.setText("Aplikasi Penjualan");

        jlabel2.setFont(new Font("Chocolate Cookies", 1, 56));
        jlabel2.setForeground(new Color(255, 255, 255));
        jlabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jlabel2.setText("Sepatu Omen");

        GroupLayout PaneMain1Layout = new GroupLayout(PaneMain1);
        PaneMain1.setLayout(PaneMain1Layout);
        PaneMain1Layout.setHorizontalGroup(
                PaneMain1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(jlabel1, GroupLayout.PREFERRED_SIZE, 1060, GroupLayout.PREFERRED_SIZE)
                        .addComponent(jlabel2, GroupLayout.PREFERRED_SIZE, 1060, GroupLayout.PREFERRED_SIZE)
        );
        PaneMain1Layout.setVerticalGroup(
                PaneMain1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(PaneMain1Layout.createSequentialGroup()
                                .addGap(201, 201, 201)
                                .addComponent(jlabel1)
                                .addGap(3, 3, 3)
                                .addComponent(jlabel2))
        );

        ParentPane.add(PaneMain1, "card2");

        lblBackground.setIcon(new ImageIcon(getClass().getResource("/Img/background.jpeg")));

        GroupLayout MainPanelLayout = new GroupLayout(MainPanel);
        MainPanel.setLayout(MainPanelLayout);
        MainPanelLayout.setHorizontalGroup(
                MainPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(ParentPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblBackground, GroupLayout.PREFERRED_SIZE, 1060, GroupLayout.PREFERRED_SIZE)
        );
        MainPanelLayout.setVerticalGroup(
                MainPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(ParentPane, GroupLayout.PREFERRED_SIZE, 550, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblBackground, GroupLayout.PREFERRED_SIZE, 550, GroupLayout.PREFERRED_SIZE)
        );

        mnOption1.setText("Option");

        kasir.setText("Kasir");
        kasir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                kasirActionPerformed(evt);
            }
        });
        mnOption1.add(kasir);

        databarang.setText("Data Barang");
        databarang.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                databarangActionPerformed(evt);
            }
        });
        mnOption1.add(databarang);

        histori.setText("Histori");
        histori.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                historiActionPerformed(evt);
            }
        });
        mnOption1.add(histori);

        MenuBarOption.add(mnOption1);

        mnOption2.setText("Help");

        mnMain.setText("Main");
        mnMain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                mnMainActionPerformed(evt);
            }
        });
        mnOption2.add(mnMain);

        mnAbout.setText("About");
        mnAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                mnAboutActionPerformed(evt);
            }
        });
        mnOption2.add(mnAbout);

        MenuBarOption.add(mnOption2);

        setJMenuBar(MenuBarOption);

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(MainPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(MainPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
        setLocationRelativeTo(null);
        Font f = new Font("CHOCHOLATE COOKIES", Font.PLAIN, 16);
        Font ff = new Font("CHOCHOLATE COOKIES", Font.PLAIN, 18);
        mnOption1.setFont(ff);
        mnOption2.setFont(ff);
        kasir.setFont(f);
        databarang.setFont(f);
        histori.setFont(f);
        mnMain.setFont(f);
        mnAbout.setFont(f);
        UIManager.put("Menu.font", f);
        pack();
    }

    public void databarangActionPerformed(ActionEvent evt) {
        ParentPane.removeAll();
        ParentPane.repaint();
        ParentPane.revalidate();
        DataBarang pk = new DataBarang();
        ParentPane.add(pk.pane);
    }

    public void historiActionPerformed(ActionEvent evt) {
        ParentPane.removeAll();
        ParentPane.repaint();
        ParentPane.revalidate();
        Histori pk = new Histori();
        ParentPane.add(pk.pane);
    }

    public void kasirActionPerformed(ActionEvent evt) {
        ParentPane.removeAll();
        ParentPane.repaint();
        ParentPane.revalidate();
        Kasir1 pk = new Kasir1();
        ParentPane.add(pk.pane);
    }

    public void mnMainActionPerformed(ActionEvent evt) {
        ParentPane.removeAll();
        ParentPane.repaint();
        ParentPane.revalidate();
        Kasir1 pk = new Kasir1();
        ParentPane.add(PaneMain1);
    }

    public void mnAboutActionPerformed(ActionEvent evt) {
        ParentPane.removeAll();
        ParentPane.repaint();
        ParentPane.revalidate();
        About pk = new About();
        ParentPane.add(pk.pane);
    }

    public static void main(String args[]) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

}
