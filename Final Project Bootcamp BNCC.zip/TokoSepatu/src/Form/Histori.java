package Form;

import Connection.ConnectionSet;
import DAO.Struk;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Histori extends JFrame {

    JPanel PaneMain;
    JTextArea TAOutput;
    JButton jButton1;
    JLabel jLabel1;
    JPanel jPanel2;
    JScrollPane jScrollPane1;
    JScrollPane jScrollPane2;
    JTable tbStruk;
    JPanel pane;
    
    Struk struk = new Struk();
    Connection con;
    ConnectionSet cn = new ConnectionSet();
    PreparedStatement ps;
    ResultSet rs;
    DefaultTableModel dtm = new DefaultTableModel();

    public Histori() {
        setLayout();
        pane = PaneMain;
        listStruk();
        loadStruk();
    }
                         
    public void setLayout() {

        PaneMain = new JPanel();
        jLabel1 = new JLabel();
        jScrollPane1 = new JScrollPane();
        tbStruk = new JTable();
        jPanel2 = new JPanel();
        jScrollPane2 = new JScrollPane();
        TAOutput = new JTextArea();
        jButton1 = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        PaneMain.setOpaque(false);
        PaneMain.setPreferredSize(new Dimension(1060, 550));

        jLabel1.setFont(new Font("Chocolate Cookies", 1, 56)); 
        jLabel1.setForeground(new Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setText("History");

        tbStruk.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Struk ID", "Kode Sepatu", "Model Sepatu", "Merk Sepatu", "Warna Sepatu", "Harga Sepatu", "Kuantitas", "Pembayaran"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbStruk.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                tbStrukMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbStruk);

        jPanel2.setBackground(new Color(51, 0, 51));
        jPanel2.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)));
        jPanel2.setOpaque(false);

        jScrollPane2.setBorder(null);

        TAOutput.setColumns(20);
        TAOutput.setRows(5);
        jScrollPane2.setViewportView(TAOutput);

        GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton1.setText("Save");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        GroupLayout PaneMainLayout = new GroupLayout(PaneMain);
        PaneMain.setLayout(PaneMainLayout);
        PaneMainLayout.setHorizontalGroup(
            PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 1060, GroupLayout.PREFERRED_SIZE)
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 740, GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(870, 870, 870)
                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
        );
        PaneMainLayout.setVerticalGroup(
            PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(PaneMain, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(PaneMain, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }                       

    public void tbStrukMouseClicked(MouseEvent evt) {  
        TAOutput.setText("");
        int row = tbStruk.getSelectedRow();
        if (row != -1) {
            int kode2 = tbStruk.getSelectedColumn();
            if (kode2 != -1) {
                String BT = String.valueOf(tbStruk.getValueAt(row, 6));
                String Total = String.valueOf(tbStruk.getValueAt(row, 4));
                String Provit = String.valueOf(tbStruk.getValueAt(row, 5));
                int total = Integer.valueOf((String) tbStruk.getValueAt(row, 5)) * Integer.valueOf((String) tbStruk.getValueAt(row, 6));
                int totall = total - Integer.valueOf((String) tbStruk.getValueAt(row, 7));
                TAOutput.setText(TAOutput.getText() + "==========================================\n\n");
                TAOutput.setText(TAOutput.getText() + "Model Sepatu : " + tbStruk.getValueAt(row, 2) + "\n");
                TAOutput.setText(TAOutput.getText() + "Merk Sepatu : " + tbStruk.getValueAt(row, 3) + "\n");
                TAOutput.setText(TAOutput.getText() + "Warna Sepatu : " + tbStruk.getValueAt(row, 4) + "\n");
                TAOutput.setText(TAOutput.getText() + "Harga Sepatu : Rp" + tbStruk.getValueAt(row, 5) + "\n");
                TAOutput.setText(TAOutput.getText() + "jumlah Sepatu : Rp" + tbStruk.getValueAt(row, 6) + "\n");
                TAOutput.setText(TAOutput.getText() + "Total Belanja : Rp" + Total + "\n");
                TAOutput.setText(TAOutput.getText() + "Pembayaran : Rp" + tbStruk.getValueAt(row, 7) + "\n");
                TAOutput.setText(TAOutput.getText() + "Kembalian : Rp" + totall + "\n\n\n");
                TAOutput.setText(TAOutput.getText() + "\n");
                TAOutput.setText(TAOutput.getText() + "");
                TAOutput.setText(TAOutput.getText() + "==========================================\n");
            } else {
                System.out.println("No");
            }
        } else {
            System.out.println("select");
        }
    }                                    

    public void jButton1ActionPerformed(ActionEvent evt) {                                         
        File FileSimpan = new File("D://Data Transaksi//RM Baru//simpan.txt");
        try {
            //Create the file
            if (FileSimpan.createNewFile()) {
                System.out.println("File is created!");
            } else {
                System.out.println("File already exists");
            }
            //Write Content
            FileWriter writer = new FileWriter(FileSimpan);
            writer.write(TAOutput.getText());
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Histori.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                        

    public void setResetTable() {
        for (int i = 0; i < dtm.getRowCount(); i++) {
            dtm.removeRow(i);
            i = i - 1;
        }
    }

    public List listStruk() {
        List<Struk> struks = new ArrayList();
        String sql = "SELECT * FROM struk";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Struk struk = new Struk();
                struk.setStruk_id(rs.getString("struk_id"));
                struk.setKode_sepatu(rs.getString("kode_sepatu"));
                struk.setModel_sepatu(rs.getString("model_sepatu"));
                struk.setMerk_sepatu(rs.getString("merk_sepatu"));
                struk.setWarna_sepatu(rs.getString("warna_sepatu"));
                struk.setHarga_sepatu(rs.getString("harga_sepatu"));
                struk.setKuantitas_sepatu(rs.getString("kuantitas_sepatu"));
                struk.setUang_pembayaran(rs.getString("uang_pembayaran"));
                struks.add(struk);
            }

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return struks;
    }

    public void loadStruk() {
        List<Struk> struks = listStruk();
        dtm = (DefaultTableModel) tbStruk.getModel();
        Object[] ob = new Object[8];
        for (int i = 0; i < struks.size(); i++) {
            ob[0] = struks.get(i).getStruk_id();
            ob[1] = struks.get(i).getKode_sepatu();
            ob[2] = struks.get(i).getModel_sepatu();
            ob[3] = struks.get(i).getMerk_sepatu();
            ob[4] = struks.get(i).getWarna_sepatu();
            ob[5] = struks.get(i).getHarga_sepatu();
            ob[6] = struks.get(i).getKuantitas_sepatu();
            ob[7] = struks.get(i).getUang_pembayaran();
            dtm.addRow(ob);
        }
        tbStruk.setModel(dtm);
    }
}
