package Form;

import Connection.ConnectionSet;
import DAO.Struk;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Kasir1 extends JFrame {
    
    JButton BTSave;
    JButton BTSave1;
    JPanel PaneMain;
    JTextArea TAOutput;
    ButtonGroup buttonGroup1;
    JLabel jLabel1;
    JLabel jLabel2;
    JLabel jLabel3;
    JLabel jLabel4;
    JLabel jLabel5;
    JLabel jLabel6;
    JLabel jLabel7;
    JLabel jLabel8;
    JLabel jLabel9;
    JLabel jLabel10;
    JPanel jPanel11;
    JScrollPane jScrollPane2;
    JTextField txt_bayar;
    JTextField txt_harga_sepatu;
    JTextField txt_jumlah;
    JTextField txt_kembalian;
    JTextField txt_kode_sepatu;
    JTextField txt_merk_sepatu;
    JTextField txt_model_sepatu;
    JTextField txt_total;
    JTextField txt_warna_sepatu;
    JPanel pane;
    Connection con;
    ConnectionSet cn = new ConnectionSet();
    PreparedStatement ps;
    ResultSet rs;

    
    Struk struk = new Struk();

    public Kasir1() {
        setLayout();
        pane = PaneMain;
    }
                       
    public void setLayout() {

        buttonGroup1 = new ButtonGroup();
        PaneMain = new JPanel();
        jPanel11 = new JPanel();
        jScrollPane2 = new JScrollPane();
        TAOutput = new JTextArea();
        BTSave = new JButton();
        jLabel9 = new JLabel();
        txt_kode_sepatu = new JTextField();
        jLabel3 = new JLabel();
        txt_model_sepatu = new JTextField();
        jLabel10 = new JLabel();
        txt_merk_sepatu = new JTextField();
        jLabel1 = new JLabel();
        txt_warna_sepatu = new JTextField();
        txt_harga_sepatu = new JTextField();
        jLabel2 = new JLabel();
        jLabel4 = new JLabel();
        txt_jumlah = new JTextField();
        jLabel5 = new JLabel();
        txt_total = new JTextField();
        jLabel6 = new JLabel();
        txt_kembalian = new JTextField();
        BTSave1 = new JButton();
        jLabel7 = new JLabel();
        txt_bayar = new JTextField();
        jLabel8 = new JLabel();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        PaneMain.setBackground(new java.awt.Color(102, 102, 102));
        PaneMain.setOpaque(false);
        PaneMain.setPreferredSize(new java.awt.Dimension(1060, 550));

        jPanel11.setBackground(new java.awt.Color(51, 0, 51));
        jPanel11.setBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel11.setOpaque(false);

        jScrollPane2.setBorder(null);

        TAOutput.setColumns(20);
        TAOutput.setRows(5);
        jScrollPane2.setViewportView(TAOutput);

        GroupLayout jPanel11Layout = new GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 250, GroupLayout.PREFERRED_SIZE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE))
        );

        BTSave.setText("Proses");
        BTSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTSaveActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Kode Sepatu");

        txt_kode_sepatu.setFont(new java.awt.Font("Arial", 0, 12));
        txt_kode_sepatu.setForeground(new java.awt.Color(204, 204, 204));
        txt_kode_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_kode_sepatu.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_kode_sepatu.setOpaque(false);
        txt_kode_sepatu.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_kode_sepatuKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("Model Sepatu");

        txt_model_sepatu.setFont(new java.awt.Font("Arial", 0, 12));
        txt_model_sepatu.setForeground(new java.awt.Color(204, 204, 204));
        txt_model_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_model_sepatu.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_model_sepatu.setOpaque(false);

        jLabel10.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel10.setForeground(new java.awt.Color(204, 204, 204));
        jLabel10.setText("Merk Sepatu");

        txt_merk_sepatu.setFont(new java.awt.Font("Arial", 0, 12));
        txt_merk_sepatu.setForeground(new java.awt.Color(204, 204, 204));
        txt_merk_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_merk_sepatu.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_merk_sepatu.setOpaque(false);

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel1.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1.setText("Warna Sepatu");

        txt_warna_sepatu.setFont(new java.awt.Font("Arial", 0, 12));
        txt_warna_sepatu.setForeground(new java.awt.Color(204, 204, 204));
        txt_warna_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_warna_sepatu.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_warna_sepatu.setOpaque(false);

        txt_harga_sepatu.setFont(new java.awt.Font("Arial", 0, 12));
        txt_harga_sepatu.setForeground(new java.awt.Color(204, 204, 204));
        txt_harga_sepatu.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_harga_sepatu.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_harga_sepatu.setOpaque(false);

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Harga Sepatu");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("Jumlah");

        txt_jumlah.setFont(new java.awt.Font("Arial", 0, 12));
        txt_jumlah.setForeground(new java.awt.Color(204, 204, 204));
        txt_jumlah.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_jumlah.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_jumlah.setOpaque(false);
        txt_jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_jumlahKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Total");

        txt_total.setFont(new java.awt.Font("Arial", 0, 12));
        txt_total.setForeground(new java.awt.Color(204, 204, 204));
        txt_total.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_total.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_total.setOpaque(false);

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Kembalian");

        txt_kembalian.setFont(new java.awt.Font("Arial", 0, 12));
        txt_kembalian.setForeground(new java.awt.Color(204, 204, 204));
        txt_kembalian.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_kembalian.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_kembalian.setOpaque(false);

        BTSave1.setText("Save");
        BTSave1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTSave1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("Total");

        txt_bayar.setFont(new java.awt.Font("Arial", 0, 12));
        txt_bayar.setForeground(new java.awt.Color(204, 204, 204));
        txt_bayar.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), BorderFactory.createEmptyBorder(1, 10, 1, 10)));
        txt_bayar.setCaretColor(new java.awt.Color(255, 255, 255));
        txt_bayar.setOpaque(false);
        txt_bayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_bayarKeyReleased(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 14));
        jLabel8.setForeground(new java.awt.Color(204, 204, 204));
        jLabel8.setText("Bayar");

        GroupLayout PaneMainLayout = new GroupLayout(PaneMain);
        PaneMain.setLayout(PaneMainLayout);
        PaneMainLayout.setHorizontalGroup(
            PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(260, 260, 260)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(txt_kode_sepatu, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_model_sepatu, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_merk_sepatu, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_warna_sepatu, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_harga_sepatu, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_jumlah, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_total, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_bayar, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_kembalian, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE))
                .addGap(90, 90, 90)
                .addComponent(jPanel11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(410, 410, 410)
                .addComponent(BTSave, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
                .addGap(340, 340, 340)
                .addComponent(BTSave1, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
        );
        PaneMainLayout.setVerticalGroup(
            PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(PaneMainLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(PaneMainLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(PaneMainLayout.createSequentialGroup()
                                .addComponent(jLabel9, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel10, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addComponent(jLabel8, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel6, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
                            .addGroup(PaneMainLayout.createSequentialGroup()
                                .addComponent(txt_kode_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_model_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_merk_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_warna_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_harga_sepatu, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_jumlah, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_total, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_bayar, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_kembalian, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))))
                .addGap(10, 10, 10)
                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(BTSave, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                    .addGroup(PaneMainLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(BTSave1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 1060, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PaneMain, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 550, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PaneMain, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }                   

    public void txt_kode_sepatuKeyReleased(KeyEvent evt) {                                            
        input(txt_kode_sepatu.getText());
    }                                           

    public void txt_jumlahKeyReleased(KeyEvent evt) {                                       
        if (txt_jumlah.getText().equals("")) {
            txt_total.setText("");
        } else {
            int total = Integer.valueOf(txt_harga_sepatu.getText()) * Integer.valueOf(txt_jumlah.getText());
            txt_total.setText(total + "");
        }
    }                                      

    public void txt_bayarKeyReleased(KeyEvent evt) {                                      
        int total = Integer.valueOf(txt_bayar.getText()) - Integer.valueOf(txt_total.getText());
        if (total < 0) {
            txt_kembalian.setText("");
        } else {
            txt_kembalian.setText(total + "");
        }
    }                                     

    public void BTSaveActionPerformed(ActionEvent evt) {                                       
        if (txt_kode_sepatu.getText().equals("") || txt_model_sepatu.getText().equals("") || txt_merk_sepatu.getText().equals("") || txt_warna_sepatu.getText().equals("") || txt_harga_sepatu.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Data Harus Lengkap");
        } else {
            struk.setKode_sepatu(txt_kode_sepatu.getText());
            struk.setModel_sepatu(txt_model_sepatu.getText());
            struk.setMerk_sepatu(txt_merk_sepatu.getText());
            struk.setWarna_sepatu(txt_warna_sepatu.getText());
            struk.setHarga_sepatu(txt_harga_sepatu.getText());
            struk.setKuantitas_sepatu(txt_jumlah.getText());
            struk.setUang_pembayaran(txt_bayar.getText());
            saveSepatu(struk);
            JOptionPane.showMessageDialog(null, "Data Ditambah");
            TAOutput.setText("");
            TAOutput.setText(TAOutput.getText() + "==========================================\n\n");
            TAOutput.setText(TAOutput.getText() + "Model Sepatu : " + txt_model_sepatu.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "Merk Sepatu : " + txt_merk_sepatu.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "Warna Sepatu : " + txt_warna_sepatu.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "Harga Sepatu : Rp" + txt_harga_sepatu.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "jumlah Sepatu : Rp" + txt_jumlah.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "Total Belanja : Rp" + txt_total.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "Pembayaran : Rp" + txt_bayar.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "Kembalian : Rp" + txt_kembalian.getText() + "\n\n\n");
            TAOutput.setText(TAOutput.getText() + "\n");
            TAOutput.setText(TAOutput.getText() + "");
            TAOutput.setText(TAOutput.getText() + "==========================================\n");
        }
    }                                      

    public void BTSave1ActionPerformed(ActionEvent evt) {                                        
        File FileSimpan = new File("D://Data Transaksi//RM Baru//simpan.txt");
        try {
            //Create the file
            if (FileSimpan.createNewFile()) {
                System.out.println("File is created!");
            } else {
                System.out.println("File already exists");
            }
            //Write Content
            FileWriter writer = new FileWriter(FileSimpan);
            writer.write(TAOutput.getText());
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Kasir1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                       

    public void input(String kode_sepatu) {
        String sql = "SELECT * FROM sepatu where kode_sepatu = '" + kode_sepatu + "'";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                txt_model_sepatu.setText(rs.getString("model_sepatu"));
                txt_merk_sepatu.setText(rs.getString("merk_sepatu"));
                txt_warna_sepatu.setText(rs.getString("warna_sepatu"));
                txt_harga_sepatu.setText(rs.getString("harga_sepatu"));
            } else {
                txt_model_sepatu.setText("");
                txt_merk_sepatu.setText("");
                txt_warna_sepatu.setText("");
                txt_harga_sepatu.setText("");
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public boolean saveSepatu(Struk struk) {
        String sql = "INSERT INTO struk "
                + "(kode_sepatu, model_sepatu, merk_sepatu, warna_sepatu, harga_sepatu,kuantitas_sepatu,uang_pembayaran) "
                + "VALUES (?,?,?,?,?,?,?)";
        try {
            con = cn.getConnect();
            ps = con.prepareStatement(sql);
            ps.setString(1, struk.getKode_sepatu());
            ps.setString(2, struk.getModel_sepatu());
            ps.setString(3, struk.getMerk_sepatu());
            ps.setString(4, struk.getWarna_sepatu());
            ps.setString(5, struk.getHarga_sepatu());
            ps.setString(6, struk.getKuantitas_sepatu());
            ps.setString(7, struk.getUang_pembayaran());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
}
