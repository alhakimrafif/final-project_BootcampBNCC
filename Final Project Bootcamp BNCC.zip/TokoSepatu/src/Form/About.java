package Form;

import javax.swing.*;

public class About extends JFrame {

    JPanel pane;
    private JPanel PaneMain;
    private JLabel jLabel1;
    private JLabel jLabel2;

    public About() {
        setLayout();
        pane = PaneMain;
    }

    private void setLayout() {

        PaneMain = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        PaneMain.setOpaque(false);
        PaneMain.setPreferredSize(new java.awt.Dimension(1060, 550));

        jLabel1.setIcon(new ImageIcon(getClass().getResource("/Img/logo-omen.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setText("Aplikasi Penjualan Sepatu");

        GroupLayout PaneMainLayout = new GroupLayout(PaneMain);
        PaneMain.setLayout(PaneMainLayout);
        PaneMainLayout.setHorizontalGroup(
                PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(PaneMainLayout.createSequentialGroup()
                                .addGroup(PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(PaneMainLayout.createSequentialGroup()
                                                .addGap(450, 450, 450)
                                                .addComponent(jLabel1))
                                        .addGroup(PaneMainLayout.createSequentialGroup()
                                                .addGap(372, 372, 372)
                                                .addComponent(jLabel2)))
                                .addGap(146, 146, 146))
        );
        PaneMainLayout.setVerticalGroup(
                PaneMainLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(PaneMainLayout.createSequentialGroup()
                                .addGap(150, 150, 150)
                                .addComponent(jLabel1)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel2)
                                .addGap(25, 25, 25))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(PaneMain, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(PaneMain, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }

}
